# Conferencia CoDA 2026

Sitio estático para GitHub Pages. El archivo index.html contiene la imagen integrada y un enlace clicable sobre el botón verde.

Publicación: Settings > Pages > Build and deployment > Deploy from a branch > main > /(root) > Save.
